// 📌 عناصر أساسية
let progress = 0;
let skillPoints = 0;

let player = {
  name: "",
  level: 1,
  hp: 100,
  mana: 100,
  maxHp: 100,
  maxMana: 100,
  xp: 0,
  kills: 0,
  power: 100,
  rank: 1
};

let enemy = {
  hp: 100,
  maxHp: 100,
  rage: 0,
  level: 1,
  power: 5
};

let skills = {
  attack: 0,
  defense: 0,
  speed: 0,
  intelligence: 0,
  magic: 0
};

// 🪟 فتح النوافذ
function openPopup(type) {
  const popup = document.getElementById("popup");
  const popupBody = document.getElementById("popup-body");
  const template = document.getElementById(`${type}-template`);
  popupBody.innerHTML = "";
  popupBody.appendChild(template.content.cloneNode(true));
  popup.classList.remove("hidden");

  if (type === "profile") loadProfile();
  if (type === "tasks") loadTasks();
  if (type === "battle") updateBattleUI();
  if (type === "skills") updateSkillUI();
  if (type === "stats") updateStats();
}

function closePopup() {
  document.getElementById("popup").classList.add("hidden");
}

// 👤 حفظ الملف الشخصي
function saveProfile() {
  const name = document.getElementById("nameInput").value;
  const age = document.getElementById("ageInput").value;
  const gender = document.getElementById("genderInput").value;

  player.name = name;
  localStorage.setItem("playerName", name);
  localStorage.setItem("playerAge", age);
  localStorage.setItem("playerGender", gender);
  alert("تم حفظ البيانات!");
}

function loadProfile() {
  document.getElementById("nameInput").value =
    localStorage.getItem("playerName") || "";
  document.getElementById("ageInput").value =
    localStorage.getItem("playerAge") || "";
  const gender = localStorage.getItem("playerGender") || "";
  document.getElementById("genderInput").value = gender;
  updateAvatar();
}

function updateAvatar() {
  const gender = document.getElementById("genderInput").value;
  const avatar = gender === "male" ? "🧑🏻" : gender === "female" ? "👩🏻" : "👤";
  const avatarPreview = document.getElementById("avatarPreview");
  if (avatarPreview) avatarPreview.textContent = avatar;
  const playerAvatar = document.getElementById("playerAvatar");
  if (playerAvatar) playerAvatar.textContent = avatar;
}

// 📝 المهام اليومية
let taskCooldown = false;
function loadTasks() {
  const tasksUl = document.getElementById("tasks-ul");
  tasksUl.innerHTML = "";

  if (taskCooldown) {
    document.getElementById("cooldown").classList.remove("hidden");
    return;
  }

  const taskList = [
    "اقتل 5 وحوش 🐉",
    "اجمع 50 خبرة 🌟",
    "استخدم مهارة سحرية 3 مرات 🔮",
    "اشفِ نفسك مرتين 💖",
    "اربح معركة بدون خسارة دم 💪",
    "افتح شجرة المهارات 🌳",
    "طور مستوى واحد على الأقل 📈",
    "أكمل مهمة بدون استخدام مانا 🧪",
    "ارفع نقطة هجوم واحدة 🗡️",
    "اضغط على زر الطاقة المخفية 💡"
  ];

  taskList.forEach((task, index) => {
    const li = document.createElement("li");
    li.innerHTML = `<label>${task}</label> <input type="checkbox" onchange="checkTasks()">`;
    tasksUl.appendChild(li);
  });
}

function checkTasks() {
  const checkboxes = document.querySelectorAll(
    '#tasks-ul input[type="checkbox"]'
  );
  const allDone = [...checkboxes].every((cb) => cb.checked);
  if (allDone) {
    player.xp += 20;
    updateProgress(20);
    startCooldown();
  }
}

function startCooldown() {
  taskCooldown = true;
  document.getElementById("tasks-ul").innerHTML = "";
  document.getElementById("cooldown").classList.remove("hidden");
  let time = 24 * 60 * 60;
  const countdown = document.getElementById("countdown");
  const interval = setInterval(() => {
    time--;
    const h = Math.floor(time / 3600)
      .toString()
      .padStart(2, "0");
    const m = Math.floor((time % 3600) / 60)
      .toString()
      .padStart(2, "0");
    const s = (time % 60).toString().padStart(2, "0");
    countdown.textContent = `${h}:${m}:${s}`;
    if (time <= 0) {
      clearInterval(interval);
      taskCooldown = false;
      document.getElementById("cooldown").classList.add("hidden");
      loadTasks();
    }
  }, 1000);
}

// ⚔️ القتال
function updateBattleUI() {
  document.getElementById("playerHealth").value = player.hp;
  document.getElementById("playerMana").value = player.mana;
  document.getElementById("playerXP").value = player.xp % 100;
  document.getElementById("enemyHealth").value = enemy.hp;
  document.getElementById("enemyRage").value = enemy.rage;
}

function attack() {
  const damage = player.power + skills.attack * 2;
  enemy.hp -= damage;
  enemy.rage += 10;
  if (enemy.hp <= 0) {
    player.kills++;
    player.xp += 10;
    updateProgress(10);
    enemy.level++;
    enemy.hp = enemy.maxHp = 100 + enemy.level * 10;
    enemy.power += 3;
    enemy.rage = 0;
  } else {
    receiveDamage();
  }
  updateBattleUI();
}

function heal() {
  if (player.mana >= 10) {
    player.hp = Math.min(player.maxHp, player.hp + 30);
    player.mana -= 10;
    receiveDamage();
    updateBattleUI();
  }
}

function useSkill() {
  if (player.mana >= 20) {
    const skillDamage = player.power + skills.magic * 5;
    enemy.hp -= skillDamage;
    player.mana -= 20;
    enemy.rage += 20;
    if (enemy.hp <= 0) {
      player.kills++;
      player.xp += 15;
      updateProgress(15);
      enemy.level++;
      enemy.hp = enemy.maxHp = 100 + enemy.level * 15;
      enemy.power += 4;
      enemy.rage = 0;
    } else {
      receiveDamage();
    }
    updateBattleUI();
  }
}

function receiveDamage() {
  let enemyPower = enemy.power;
  if (enemy.rage >= 100) {
    enemyPower *= 2;
    enemy.rage = 0;
  }
  player.hp -= enemyPower;
  if (player.hp <= 0) {
    const popup = document.getElementById("popup");
    const popupBody = document.getElementById("popup-body");
    popupBody.innerHTML = `
      <h2>😵 لقد خسرت!</h2>
      <p>تم إعادتك بصحة كاملة.</p>
    `;
    popup.classList.remove("hidden");
    player.hp = player.maxHp;
    player.mana = player.maxMana;
  }
}

// 🌟 شجرة المهارات
function updateSkillUI() {
  for (let key in skills) {
    document.getElementById(`${key}Level`).textContent = skills[key];
  }
  const container = document.querySelector(".skills-tree h3");
  if (container) {
    container.innerHTML = `🌳 شجرة المهارات <span style="font-size:14px; color:#ffaa00;">(${skillPoints} نقطة)</span>`;
  }
}

function increaseSkill(type) {
  if (skillPoints > 0) {
    skills[type]++;
    skillPoints--;
    updateSkillUI();
    calculatePower();
  } else {
    alert("❌ لا توجد نقاط مهارة كافية!");
  }
}

function decreaseSkill(type) {
  if (skills[type] > 0) {
    skills[type]--;
    skillPoints++;
    updateSkillUI();
    calculatePower();
  }
}

function calculatePower() {
  player.power = 10 + skills.attack * 2 + skills.magic * 1.5;
}

// 📊 الإحصائيات
function updateStats() {
  document.getElementById("statName").textContent = player.name || "---";
  document.getElementById("statLevel").textContent = player.level;
  document.getElementById("statHP").textContent = player.maxHp;
  document.getElementById("statMana").textContent = player.maxMana;
  document.getElementById("statPower").textContent = Math.floor(player.power);
  document.getElementById("xpBar").value = player.xp % 100;
  document.getElementById("killsCount").textContent = player.kills;
}

// ⬆️ ترقية المستوى (نافذة فقط)
function levelUp() {
  const popup = document.getElementById("popup");
  const popupBody = document.getElementById("popup-body");

  if (player.xp >= 100) {
    player.level++;
    player.xp -= 100;
    player.maxHp += 20;
    player.maxMana += 10;
    player.power += 100;
    player.hp = player.maxHp;
    player.mana = player.maxMana;
    skillPoints += 5;
    updateProgress(0);

    popupBody.innerHTML = `
      <h2>🎉 تم رفع مستواك!</h2>
      <p>مستواك الآن: <strong>${player.level}</strong></p>
      <p>تمت إضافة <strong>5 نقاط مهارة</strong>.</p>
    `;
  } else {
    popupBody.innerHTML = `
      <h2>❌ لا يمكنك الترقية</h2>
      <p>تحتاج إلى 100 خبرة. لديك فقط <strong>${player.xp}</strong>.</p>
    `;
  }

  popup.classList.remove("hidden");
}

// 🆙 ترقية الفئة (نافذة فقط)
function rankUp() {
  const popup = document.getElementById("popup");
  const popupBody = document.getElementById("popup-body");

  if (player.level >= player.rank * 10) {
    player.rank++;
    popupBody.innerHTML = `
      <h2>🏅 تم ترقية الفئة!</h2>
      <p>الفئة الجديدة: <strong>${player.rank}</strong></p>
    `;
  } else {
    popupBody.innerHTML = `
      <h2>❌ لم يتم الترقية</h2>
      <p>يجب الوصول إلى المستوى <strong>${player.rank * 10}</strong>.</p>
    `;
  }

  popup.classList.remove("hidden");
}

// ❓ شرح الفئات (نافذة فقط)
function showRankHelp() {
  const popup = document.getElementById("popup");
  const popupBody = document.getElementById("popup-body");

  const ranks = [
    { level: 1, title: "مبتدئ", desc: "البداية" },
    { level: 10, title: "متدرب", desc: "بدأت تكتسب مهارات" },
    { level: 20, title: "مقاتل ناشئ", desc: "قدرتك بدأت تظهر" },
    { level: 30, title: "مقاتل محترف", desc: "أصبحت أقوى وأكثر خبرة" },
    { level: 40, title: "قائد فرقة", desc: "تستطيع قيادة المعارك" },
    { level: 50, title: "بطل", desc: "شخصية بارزة في عالم القتال" },
    { level: 60, title: "أسطورة", desc: "بدأت تدخل الأساطير" },
    { level: 70, title: "مظلم مطور", desc: "تمتلك طاقات غير طبيعية" },
    { level: 80, title: "سيد الطاقات", desc: "تتحكم بقوى خارقة" },
    { level: 90, title: "الحاكم الأعلى", desc: "لا أحد يقدر على مواجهتك" },
    { level: 100, title: "سيد العالم", desc: "وصلت إلى قمة السيطرة" }
  ];

  let html = "<h2>🏅 نظام الفئات</h2><ul>";
  ranks.forEach((rank) => {
    html += `<li>🔹 مستوى ${rank.level}: <strong>${rank.title}</strong> — ${rank.desc}</li>`;
  });
  html += "</ul>";

  popupBody.innerHTML = html;
  popup.classList.remove("hidden");
}

// 🎯 التقدم العام
function updateProgress(xpGain) {
  progress += xpGain;
  if (progress > 1000) progress = 1000;
  document.getElementById("progress-text").textContent = `${progress} / 1000`;
}
